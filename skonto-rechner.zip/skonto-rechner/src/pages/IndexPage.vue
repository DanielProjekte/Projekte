<template>
    <SkontoRechner />
</template>
<script>
import SkontoRechner from 'components/SkontoRechner.vue'
export default {
  name: 'IndexPage',
  components: {
    SkontoRechner
  },
  data() {
    return {}
   },
  methods: {}
}
</script>
