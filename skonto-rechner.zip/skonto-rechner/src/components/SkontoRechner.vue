<template>

<div class="skonto-rechner-container">


<!-- Input Felder, Button und Titel -->



<div class="row justify-center">

  <h1 class="text-h4 title">Skonto-Rechner</h1>

</div>


  <div class="row justify-center q-gutter-md q-mt-md">


    <div class="col-auto">

      <q-input rounded outlined
        v-model="betrag"
        label="Betrag in €"
        type="number"
        suffix="€"
        class="q-mb-md"
        @keydown="blockiereEingabe"
  />
    </div>

    <div class="col-auto">

      <q-input rounded outlined
        v-model="skontoProzent"
        label="Skonto in %"
        type="number"
        suffix="%"
        class="q-mb-md"
        @keydown="blockiereEingabe"
  />
    </div>
</div>

<div class="row justify-center">

    <q-btn class = "berechnen-btn"
      label="Skonto berechnen"
      @click="berechneSkonto"
  />

</div>


  <!-- Quasar-Flex-Grid-->


 <div class="row q-gutter-lg q-mt-md q-px-md ">


  <div class="col">
      <q-card>
        <q-card-section>
          <div class="text-h6">Rechnungsbetrag</div>
          <p class="ergebnis-zahl">{{ parseFloat(rechnungsbetrag).toFixed(2) }} €</p>
        </q-card-section>
      </q-card>
    </div>




    <div class="col">
      <q-card>
        <q-card-section>
          <div class="text-h6">Skonto-Betrag</div>
          <p class="ergebnis-zahl">{{ parseFloat(skontoBetrag).toFixed(2) }} €</p>
        </q-card-section>
      </q-card>
    </div>




    <div class="col">
      <q-card>
        <q-card-section>
          <div class="text-h6">Gesamtkosten</div>
          <p class="ergebnis-zahl">{{ parseFloat(gesamtkosten).toFixed(2) }} €</p>
        </q-card-section>
      </q-card>
    </div>




    <div class="col">
      <q-card>
        <q-card-section>
          <div class="text-h6">Finanzieller Vorteil</div>
          <p class="ergebnis-zahl">{{ parseFloat(finanziellerVorteil).toFixed(2) }} €</p>
        </q-card-section>
      </q-card>
    </div>

  </div>

</div>


</template>
<script src="./SkontoRechner.js"></script>
<style lang="scss" src="./SkontoRechner.scss"></style>
