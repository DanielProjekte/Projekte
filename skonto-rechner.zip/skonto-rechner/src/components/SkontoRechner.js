export default {
  name: 'SkontoRechner',
  data() {
    return {
      betrag: null,
      skontoProzent: null,
      skontoBetrag: 0,
      gesamtkosten: 0,
      finanziellerVorteil: 0,
      rechnungsbetrag: 0
    }
  },
  methods: {
    berechneSkonto() {
      if (this.betrag !== null && this.skontoProzent !== null) {
        this.skontoBetrag = (this.betrag * this.skontoProzent) / 100;
        this.gesamtkosten = this.betrag - this.skontoBetrag;
        this.finanziellerVorteil = this.skontoBetrag;
        this.rechnungsbetrag = this.betrag;
      }
      return null;
    },
    blockiereEingabe(event) {
      const verboteneTasten = ['e', 'E', '+', '-'];
      if (verboteneTasten.includes(event.key)) {
        event.preventDefault();
      }
    }
  }
}

